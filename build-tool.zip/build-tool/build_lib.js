// TODO not support pack library's res yet
// TODO not fix different version dependencies problem yet

const fs = require('fs');
const child_process = require('child_process');

const androiduiLibPath = 'androidui-lib';
const libJSFilePath = 'build/lib.js';
const libTSFilePath = 'build/lib.d.ts';
const libES5JSFilePath = 'build/lib.es5.js';
// init flag: ignore rebuild if lib file already exist.
if(process.argv[2] === '-init' && fs.existsSync(libJSFilePath) && fs.existsSync(libTSFilePath) && fs.existsSync(libES5JSFilePath)) {
    return;
}
// create file
fs.writeFileSync(libJSFilePath, '', 'utf-8');
fs.writeFileSync(libTSFilePath, '', 'utf-8');
fs.writeFileSync(libES5JSFilePath, '', 'utf-8');

// 1. install dependencies
console.log('downloading library dependencies...');
child_process.exec(`cd ${androiduiLibPath} && npm install`, function(err,stdout,stderr){
    if (err) {
        console.error(`exec error: ${err}`);
        console.log('stderr:\n' + stderr);
        console.log('stdout:\n' + stdout);
        return;
    }

    // 2. build library res
    fs.readdirSync(androiduiLibPath).forEach(function (subDirName) {
        const libParentPath = androiduiLibPath + '/' + subDirName;
        if (!fs.statSync(libParentPath).isDirectory()) return;
        fs.readdirSync(libParentPath).forEach(function (libDirName) {
            const libPath = libParentPath + '/' + libDirName;
            if (!fs.statSync(libPath).isDirectory()) return;
            var androidUIPackageName;
            try {
                androidUIPackageName = JSON.parse(fs.readFileSync(`./${libPath}/package.json`, 'utf-8')).androidUIPackageName;
            } catch (e) {
            }
            try {
                console.log(`building library resource...(${libPath})`);
                const packageNameArg = androidUIPackageName ? androidUIPackageName : '';
                child_process.execSync(`cd ${libPath} && node ../../../build-tool/build_lib_res.js ${packageNameArg}`, {stdio:[0,1,2]});
            } catch (e) {
                console.error(`build library error: ${e}`);
            }
        });
    });

    // 3. library ts2es6
    console.log('converting library TypeScript to ES6...');
    child_process.exec(`\"node_modules/.bin/tsc\" -p ${androiduiLibPath}`, function (err, stdout, stderr) {
        if (err) {
            console.error(`exec error: ${err}`);
            console.log('stderr:\n' + stderr);
            console.log('stdout:\n' + stdout);
            return;
        }

        // 4. library es62es5
        console.log('converting library ES6 to ES5...');
        child_process.exec(`\"node_modules/.bin/babel\" build/lib.js -o build/lib.es5.js -s --presets=es2015`, function (err, stdout, stderr) {
            if (err) {
                console.error(`exec error: ${err}`);
                console.log('stderr:\n' + stderr);
                console.log('stdout:\n' + stdout);
                return;
            }
            console.log('build library success');
        });
    });
});


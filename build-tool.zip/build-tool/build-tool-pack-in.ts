///<reference path="../androidui-sdk/android-ui.d.ts"/>

/**
 * buildTool in runtime, will pack to lib.js
 */
module androidui._buildTool {
    import Resources = android.content.res.Resources;
    import Drawable = android.graphics.drawable.Drawable;
    import NetDrawable = androidui.image.NetDrawable;
    import NinePatchDrawable = androidui.image.NinePatchDrawable;
    import NetImage = androidui.image.NetImage;
    import ColorDrawable = android.graphics.drawable.ColorDrawable;

    // export functions
    const AllBuildResDataFinderMap = new Map<String, BuildResDataFinder>();
    export function addPackedResData(res_data:any, packageName:string) {
        if (!res_data) return;
        const finder = AllBuildResDataFinderMap.get(packageName);
        if (finder && finder.res_data !== res_data) {
            function deepAssign(target, src) {
                for(let key in src) {
                    if (typeof target[key] === 'object' && typeof src[key] === 'object') {
                        deepAssign(target[key], src[key]);
                    } else if (src[key]) {
                        target[key] = src[key];
                    }
                }
            }
            deepAssign(finder.res_data, res_data);
        }
        if (!finder) {
            AllBuildResDataFinderMap.set(packageName, new BuildResDataFinder(res_data));
        }
    }

    // init app resource find
    if('_AppBuildValueFinder' in Resources){
        function getBuildResDataFinder(packageName):BuildResDataFinder {
            const finder = AllBuildResDataFinderMap.get(packageName);
            if (!finder) throw Error('not found packed BuildResDataFinder, packageName: ' + packageName);
            return finder;
        }
        Resources._AppBuildDrawableFinder = (refString:string):Drawable => {
            const matchDrawable = refString.match(/@(.*):drawable\/(.*)/) || refString.match(/@(.*)drawable\/(.*)/);
            if (matchDrawable) {
                const finder = getBuildResDataFinder(matchDrawable[1]);
                const fileName = matchDrawable[2];
                let d = finder.findImageFile(fileName);
                if (d) return d;

                let ele = finder.findXmlFile('drawable', fileName);
                if(ele){
                    return Drawable.createFromXml(Resources.getSystem(), ele);
                }
                ele = Resources.getSystem().getValue(refString);
                if(ele){
                    if (ele.firstElementChild) {
                        return Drawable.createFromXml(Resources.getSystem(), <HTMLElement>ele.firstElementChild);
                    }
                    let newRefString = ele.innerText;
                    try {
                        if (newRefString.startsWith('#')) {
                            return new ColorDrawable(android.graphics.Color.parseColor(newRefString)); // color
                        }
                        return Resources._AppBuildDrawableFinder(newRefString);
                    } catch (e) {
                        console.warn(e);
                    }
                }
            } else if (refString.match(/@(.*):color\/(.*)/) || refString.match(/@(.*)color\/(.*)/)) {
                return new ColorDrawable(Resources.getSystem().getColor(refString));
            }
        };
        Resources._AppBuildXmlFinder = (refString:string):HTMLElement =>{
            const match = refString.match(/@(.*):(.*)\/(.*)/) || refString.match(/@()(.*)\/(.*)/);
            return match && getBuildResDataFinder(match[1]).findXmlFile(match[2], match[3]);
        };
        Resources._AppBuildValueFinder = (refString:string):HTMLElement =>{
            const match = refString.match(/@(.*):(.*)\/(.*)/) || refString.match(/@()(.*)\/(.*)/);
            return match && getBuildResDataFinder(match[1]).findResourcesValue(match[2], match[3]);
        };

    }else{
        throw Error('Error: sdk version is too old. Please update your androidui sdk.');
    }

    class BuildResDataFinder {
        res_data:any;
        matchDirNamesCache = {};
        imageFileCache = new Map<String, NetImage>();
        static _tempDiv = document.createElement('div');

        constructor(res_data:any) {
            this.res_data = res_data;
        }

        static isResDirNameSpecMatch(spec:string):boolean {
            spec = spec.toLocaleLowerCase();

            let ratio = window.devicePixelRatio;
            if(ratio===0.75 && spec==='ldpi') return true;
            if(ratio===1 && spec==='mdpi') return true;
            if(ratio===1.5 && spec==='hdpi') return true;
            if(ratio===2 && spec==='xhdpi') return true;
            if(ratio===3 && spec==='xxhdpi') return true;
            if(ratio===4 && spec==='xxxhdpi') return true;

            let dpi = ratio * 160;
            if(spec === dpi + 'dpi') return true;

            let xdp = document.documentElement.offsetWidth;
            let ydp = document.documentElement.offsetHeight;
            let minDP = Math.min(xdp, ydp);
            let maxDP = Math.max(xdp, ydp);
            if(spec==='xlarge' && maxDP > 960 && minDP > 720) return true;
            if(spec==='large' && maxDP > 640 && minDP > 480) return true;
            if(spec==='normal' && maxDP > 470 && minDP > 320) return true;
            if(spec==='small' && maxDP > 426 && minDP > 320) return true;

            if(spec==='port' && ydp > xdp) return true;
            if(spec==='land' && xdp > ydp) return true;

            if(spec === xdp + 'x' + ydp || spec === ydp + 'x' + xdp) return true;

            let swMatch = spec.match(/sw(d*)dp/);
            if(swMatch && parseInt(swMatch[1]) >= minDP) return true;

            let wMatch = spec.match(/w(d*)dp/);
            if(wMatch && parseInt(wMatch[1]) >= xdp) return true;

            let hMatch = spec.match(/h(d*)dp/);
            if(hMatch && parseInt(hMatch[1]) >= ydp) return true;

            const lang = navigator.language.toLocaleLowerCase().split('-')[0];
            if(lang === spec) return true;
            if(spec.startsWith('r')){//rCN
                const specArea = spec.substring(1);
                const langArea = navigator.language.toLocaleLowerCase().split('-')[1];
                if(langArea === specArea) return true;
            }
        }

        findMatchDirNames(baseDirName:string):string[] {
            if(this.matchDirNamesCache[baseDirName]) return this.matchDirNamesCache[baseDirName];
            let matchDirNames = [];
            for(let dirName in this.res_data){
                if(dirName === baseDirName || dirName.startsWith(baseDirName+'-')){
                    matchDirNames.push(dirName);
                }
            }

            matchDirNames = matchDirNames.sort((a:string, b:string):number=>{
                let bSplits = b.split('-');
                bSplits.shift();
                let bMatchTimes = 0;
                for(let split of bSplits){
                    if(BuildResDataFinder.isResDirNameSpecMatch(split)) bMatchTimes++;
                }

                let aSplits = a.split('-');
                aSplits.shift();
                let aMatchTimes = 0;
                for(let split of aSplits){
                    if(BuildResDataFinder.isResDirNameSpecMatch(split)) aMatchTimes++;
                }

                return bMatchTimes - aMatchTimes;
            });
            this.matchDirNamesCache[baseDirName] = matchDirNames;
            return matchDirNames;
        }

        findResourcesValue(valueType:string, valueName:string):HTMLElement {
            for(let dirName of this.findMatchDirNames('values')){
                let dir = this.res_data[dirName];
                if(dir[valueType] && dir[valueType][valueName]){
                    BuildResDataFinder._tempDiv.innerHTML = dir[valueType][valueName];
                    let data = <HTMLElement>BuildResDataFinder._tempDiv.firstElementChild;
                    if (data) BuildResDataFinder._tempDiv.removeChild(data);
                    return data;
                }
            }
        }

        findXmlFile(baseDirName:string, fileName:string):HTMLElement {
            for(let dirName of this.findMatchDirNames(baseDirName)){
                let dir = this.res_data[dirName];
                if(dir[fileName]){
                    BuildResDataFinder._tempDiv.innerHTML = dir[fileName];
                    let data = <HTMLElement>BuildResDataFinder._tempDiv.firstElementChild;
                    if (data) BuildResDataFinder._tempDiv.removeChild(data);
                    return data;
                }
            }
        }

        findImageFile(fileName:string):Drawable {
            //find in drawable dir
            for(let dirName of this.findMatchDirNames('drawable')) {
                let dir = this.res_data[dirName];
                if (dirName === 'drawable'){ // find ratio image first :  xxx@2x.png, xxx@3x.png
                    const findImageWithRatioName = (ratio:number) => {
                        let fileNameWithRatio = fileName + '@' + ratio + 'x';
                        let key = dirName + '/' + fileNameWithRatio;
                        let netImage = this.imageFileCache.get(key);
                        if (!netImage) {
                            let fileStr = dir[fileNameWithRatio];
                            if(fileStr && fileStr.startsWith('data:image')) {
                                netImage = new NetImage(fileStr, ratio);
                                this.imageFileCache.set(key, netImage);
                            }
                        }
                        if (netImage) return new NetDrawable(netImage);

                        // nine patch image
                        let fileNameWithNinePatch = fileName + '@' + ratio + 'x' + '.9';
                        key = dirName + '/' + fileNameWithNinePatch;
                        netImage = this.imageFileCache.get(key);
                        if (!netImage) {
                            let fileStr = dir[fileNameWithNinePatch];
                            if (fileStr && fileStr.startsWith('data:image')) {
                                netImage = new NetImage(fileStr, ratio);
                                this.imageFileCache.set(key, netImage);
                            }
                        }
                        if (netImage) return new NinePatchDrawable(netImage);
                        return null;
                    };

                    let ratioDrawable = findImageWithRatioName(window.devicePixelRatio);
                    if (!ratioDrawable && window.devicePixelRatio !== 3) ratioDrawable = findImageWithRatioName(3);
                    if (!ratioDrawable && window.devicePixelRatio !== 2) ratioDrawable = findImageWithRatioName(2);
                    if (!ratioDrawable && window.devicePixelRatio !== 4) ratioDrawable = findImageWithRatioName(4);
                    if (!ratioDrawable && window.devicePixelRatio !== 1) ratioDrawable = findImageWithRatioName(1);
                    if (!ratioDrawable && window.devicePixelRatio !== 5) ratioDrawable = findImageWithRatioName(5);
                    if (!ratioDrawable && window.devicePixelRatio !== 6) ratioDrawable = findImageWithRatioName(6);
                    if (ratioDrawable) return ratioDrawable;
                }

                let ratio = 1;
                if(dirName.includes('-')) {
                    if (dirName.includes('-ldpi')) ratio = 0.75;
                    else if (dirName.includes('-mdpi')) ratio = 1;
                    else if (dirName.includes('-hdpi')) ratio = 1.5;
                    else if (dirName.includes('-xhdpi')) ratio = 2;
                    else if (dirName.includes('-xxhdpi')) ratio = 3;
                    else if (dirName.includes('-xxxhdpi')) ratio = 4;
                }

                let key = dirName + '/' + fileName;
                let netImage = this.imageFileCache.get(key);
                if (!netImage) {
                    let fileStr = dir[fileName];
                    if(fileStr && fileStr.startsWith('data:image')) {
                        netImage = new NetImage(fileStr, ratio);
                        this.imageFileCache.set(key, netImage);
                    }
                }
                if (netImage) return new NetDrawable(netImage);

                let fileNameWithNinePatch = fileName+'.9';
                key = dirName + '/' + fileNameWithNinePatch;
                netImage = this.imageFileCache.get(key);
                if (!netImage) {
                    let fileStr = dir[fileNameWithNinePatch];
                    if (fileStr && fileStr.startsWith('data:image')) {
                        netImage = new NetImage(fileStr, ratio);
                        this.imageFileCache.set(key, netImage);
                    }
                }
                if (netImage) return new NinePatchDrawable(netImage);
            }
        }

    }
}
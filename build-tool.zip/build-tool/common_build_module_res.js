"use strict";

var fs = require('fs');
var jsdom = require('jsdom');
const ignoreDefinedId = { // defined in framework
    android: ['content', 'background', 'secondaryProgress', 'progress', 'contentPanel', 'topPanel', 'buttonPanel',
        'customPanel', 'custom', 'titleDivider', 'titleDividerTop', 'title_template', 'icon', 'alertTitle',
        'scrollView', 'message', 'button1', 'button2', 'button3', 'leftSpacer', 'rightSpacer', 'text1',
        'parentPanel', 'select_dialog_listview']
};

module.exports = function (option) {
    const refs = option.refs;
    const packageName = option.packageName || '';
    const packageNamePreFix = packageName ? `${packageName}:` : '';


    const definedIds = new Set();
    const definedDrawables = new Set();
    const definedLayouts = new Set();
    const definedColors = new Set();
    const definedArrays = new Set();
    const definedStrings = new Set();
    const definedBools = new Set();
    const definedInts = new Set();
    const definedDimens = new Set();
    const definedFractions = new Set();
    const definedStyles = new Set();

    buildResource();

    function buildResource() {
        const resPath = 'res';
        if (!fs.existsSync(resPath)) return;
        if (!fs.existsSync('gen')) fs.mkdirSync('gen');

        // res_data.ts
        const resData = {};
        fs.readdirSync(resPath).forEach(function (resSubDirName) {
            if (resSubDirName.indexOf('.') === 0) return;
            const packedDir = packDir(resPath + '/' + resSubDirName);
            if (packedDir) {
                resData[resSubDirName] = packedDir;
            }
        });

        const resDataStr = `${refs.map((item) => `///<reference path="${item}"/>`).join('\n')}

module R {
    const res_data = ${JSON.stringify(resData, null, 8)};
    
    androidui._buildTool.addPackedResData(res_data, '${packageName}');
}
`;
        fs.writeFile('gen/res_data.ts', resDataStr, 'utf-8');


        // R.ts
        const RStr = `${refs.map((item) => `///<reference path="${item}"/>`).join('\n')}

module ${packageName ? packageName + '.' : ''}R {
    import Resources = android.content.res.Resources;
    import Drawable = android.graphics.drawable.Drawable;
    
    export module id {
${Array.from(definedIds).map((item) => {
    if (ignoreDefinedId[packageName] && ignoreDefinedId[packageName].indexOf(item) !== -1) return '';
    return `        export var ${item} = '${packageNamePreFix + item}';`
}).join('\n')}
    }
    
    export module layout {
${Array.from(definedLayouts).map((item) =>
`        export var ${item} = '@${packageNamePreFix}layout/${item}';`).join('\n')}
    }
    
    export module style {
${Array.from(definedStyles).map((item) =>
`        export var ${item.replace(new RegExp("\\.", "g"), "_")} = '@${packageNamePreFix}style/${item}';`).join('\n')}
    }
    
    export module color {
${Array.from(definedColors).map((item) =>
`        export var ${item} = '@${packageNamePreFix}color/${item}';`).join('\n')}
    }
    
    export module array {
${Array.from(definedArrays).map((item) =>
`        export var ${item} = '@${packageNamePreFix}array/${item}';`).join('\n')}
    }
    
    export module integer {
${Array.from(definedInts).map((item) =>
`        export var ${item} = '@${packageNamePreFix}int/${item}';`).join('\n')}
    }
    
    export module fraction {
${Array.from(definedFractions).map((item) =>
`        export var ${item} = '@${packageNamePreFix}fractions/${item}';`).join('\n')}
    }
    
${definedDrawables.size ? `
    export module drawable {
${Array.from(definedDrawables).map((item) =>
            `        export var ${item}:Drawable;`).join('\n')}
    }
    Object.defineProperties(drawable, {
${Array.from(definedDrawables).map((item) =>
            `        ${item}: {
            get() { return Resources._AppBuildDrawableFinder('@${packageNamePreFix}drawable/${item}'); }
        }`).join(',\n')}
    });
` : ''}
${definedStrings.size ? `
    export module string {
${Array.from(definedStrings).map((item) =>
            `        export var ${item}:string;`).join('\n')}
    }
    Object.defineProperties(string, {
        ${Array.from(definedStrings).map((item) =>
            `        ${item}: {
            get() { return Resources.getSystem().getString('@${packageNamePreFix}string/${item}'); }
        }`).join(',\n')}
    });
` : ''}
${definedBools.size ? `
    export module bool {
${Array.from(definedBools).map((item) =>
            `        export var ${item}:boolean;`).join('\n')}
    }
    Object.defineProperties(bool, {
        ${Array.from(definedBools).map((item) =>
            `        ${item}: {
            get() { return Resources.getSystem().getBoolean('@${packageNamePreFix}bool/${item}'); }
        }`).join(',\n')}
    });
` : ''}
}
`;
        fs.writeFile('gen/R.ts', RStr, 'utf-8');
    }

    function packDir(resSubDirPath) {
        const dirPack = {};
        if (resSubDirPath === 'res/drawable' || resSubDirPath.indexOf('res/drawable-') === 0) {//drawable
            traverseFile(resSubDirPath, function (filePath) {
                const fileName = filePath.split('/').pop();
                const splits = fileName.split('.');
                if (splits.length <= 1) return;
                const fileSuffixes = splits[splits.length - 1];
                const fileNameNoSuf = fileName.substring(0, fileName.length - 1 - fileSuffixes.length);

                switch (fileSuffixes) {
                    case 'png':
                    case 'jpg':
                    case 'gif':
                    case 'webp':
                        let imageFilePureName = fileNameNoSuf;
                        if (imageFilePureName.endsWith('.9')) {
                            imageFilePureName = imageFilePureName.substring(0, imageFilePureName.length - 2);
                        }
                        if (imageFilePureName.endsWith('@1x') || imageFilePureName.endsWith('@2x') || imageFilePureName.endsWith('@3x')
                            || imageFilePureName.endsWith('@4x') || imageFilePureName.endsWith('@5x') || imageFilePureName.endsWith('@6x')) {
                            imageFilePureName = imageFilePureName.substring(0, imageFilePureName.length - 3);
                        }
                        definedDrawables.add(imageFilePureName);
                        const base64Data = fs.readFileSync(filePath, 'base64');
                        dirPack[fileNameNoSuf] = `data:image/${fileSuffixes};base64,${base64Data}`;
                        break;

                    case 'xml':
                        const document = readXmlFile(filePath);
                        deepTravelElement(document.documentElement);
                        definedDrawables.add(fileNameNoSuf);
                        dirPack[fileNameNoSuf] = document.documentElement.outerHTML;
                        break;
                    default:
                        console.warn('Not support file in res dir. skip :' + filePath);
                }
            });

        } else if (resSubDirPath === 'res/layout' || resSubDirPath.indexOf('res/layout-') === 0) {//layout
            traverseFile(resSubDirPath, function (filePath) {
                const fileName = filePath.split('/').pop();
                const splits = fileName.split('.');
                if (splits.length <= 1) return;
                const fileSuffixes = splits[splits.length - 1];
                const fileNameNoSuf = fileName.substring(0, fileName.length - 1 - fileSuffixes.length);
                if (fileSuffixes == 'xml') {
                    const document = readXmlFile(filePath);
                    deepTravelElement(document.documentElement);
                    definedLayouts.add(fileNameNoSuf);
                    dirPack[fileNameNoSuf] = document.documentElement.outerHTML;
                } else if (fileSuffixes == 'html') {
                    const document = readHtmlFile(filePath);
                    var rootNode = document.body.firstElementChild;
                    deepTravelElement(rootNode);
                    definedLayouts.add(fileNameNoSuf);
                    dirPack[fileNameNoSuf] = rootNode.outerHTML;
                } else {
                    console.warn('Not support file in res dir. skip :' + filePath);
                }
            });

        } else if (resSubDirPath === 'res/color' || resSubDirPath.indexOf('res/color-') === 0) {//color
            traverseFile(resSubDirPath, function (filePath) {
                const fileName = filePath.split('/').pop();
                const splits = fileName.split('.');
                if (splits.length <= 1) return;
                const fileSuffixes = splits[splits.length - 1];
                const fileNameNoSuf = fileName.substring(0, fileName.length - 1 - fileSuffixes.length);
                if (fileSuffixes == 'xml') {
                    const document = readXmlFile(filePath);
                    definedColors.add(fileNameNoSuf);
                    dirPack[fileNameNoSuf] = document.documentElement.outerHTML;
                } else {
                    console.warn('Not support file in res dir. skip :' + filePath);
                }
            });

        } else if (resSubDirPath === 'res/values' || resSubDirPath.indexOf('res/values-') === 0) {//color
            traverseFile(resSubDirPath, function (filePath) {
                const fileName = filePath.split('/').pop();
                const splits = fileName.split('.');
                if (splits.length <= 1) return;
                const fileSuffixes = splits[splits.length - 1];
                if (fileSuffixes == 'xml') {
                    const document = readXmlFile(filePath);
                    readResourcesXmlToPack(document.documentElement, filePath, dirPack);
                } else if (fileSuffixes == 'html') {
                    console.warn('No longer support html file to defined resource. skip :' + filePath);
                } else {
                    console.warn('Not support file in res dir. skip :' + filePath);
                }
            });

        } else {
            console.error('Resources file can only put in res/drawable, res/layout, res/color or res/values : ' + resSubDirPath);
            return;
        }
        return dirPack;

    }

    function readXmlFile(filePath) {
        let xml = fs.readFileSync(filePath, 'utf-8');
        xml = xml.replace(new RegExp("\\\\n", "g"), "\n");
        xml = xml.replace(new RegExp("\\\\r", "g"), "\r");
        xml = xml.replace(new RegExp("\\\\t", "g"), "\t");
        const doc = jsdom.jsdom(xml, {parsingMode: 'xml'});
        return doc.defaultView.document;
    }

    function readHtmlFile(filePath) {
        let html = fs.readFileSync(filePath, 'utf-8');
        html = html.replace(new RegExp("\\\\n", "g"), "\n");
        html = html.replace(new RegExp("\\\\r", "g"), "\r");
        html = html.replace(new RegExp("\\\\t", "g"), "\t");
        const doc = jsdom.jsdom(html, {parsingMode: 'html'});
        return doc.defaultView.document;
    }

    function readResourcesXmlToPack(doc, filePath, resPack) {
        if (doc.tagName.toLowerCase() == 'resources') {
            for (let child of Array.from(doc.children)) {
                let resType = child.tagName.toLowerCase();
                if (resType == 'item') {
                    resType = child.getAttribute('type');
                }
                let resName = child.getAttribute('name');
                if (!resName) {
                    console.error('Resources need attribute \'name\', file:' + filePath + ', xml:' + child.outerHTML);
                    return;
                }
                switch (resType) {
                    case 'id':
                        definedIds.add(resName);
                        continue;
                    case 'color':
                        definedColors.add(resName);
                        break;
                    case 'drawable':
                        definedDrawables.add(resName);
                        break;
                    case 'array':
                    case 'string-array':
                    case 'integer-array':
                        resType = 'array';
                        definedArrays.add(resName);
                        break;
                    case 'string':
                        definedStrings.add(resName);
                        break;
                    case 'bool':
                        definedBools.add(resName);
                        break;
                    case 'integer':
                        definedInts.add(resName);
                        break;
                    case 'dimen':
                        definedDimens.add(resName);
                        break;
                    case 'fraction':
                        definedFractions.add(resName);
                        break;
                    case 'style':
                        definedStyles.add(resName);
                        break;
                    default:
                        console.error('Not support resources type:' + resType + ', xml: ' + child.outerHTML);
                        return;
                }
                resPack[resType] = resPack[resType] || {};

                resPack[resType][resName] = child.outerHTML
                    .replace(new RegExp("<style", "g"), "<android-style")
                    .replace(new RegExp("</style>", "g"), "</android-style>");
            }
            return resPack;

        } else {
            console.error('Resources xml file\'s root tag must be \'resources\'. file:' + filePath);
        }
    }

    function deepTravelElement(ele) {
        if (ele) {
            //id="@+id/xx" ==> android:id="xx",
            let id = ele.getAttribute('android:id') || ele.getAttribute('id');
            ele.removeAttribute('id');
            if (id) {
                if (id.startsWith('@+id/')) id = id.substring('@+id/'.length);
                else if (id.startsWith('@id/')) id = id.substring('@id/'.length);
                else if (id.startsWith(`@${packageName}:id/`)) id = id.substring(`@${packageName}:id/`.length);
                else if (id.startsWith(`@+${packageName}:id/`)) id = id.substring(`@+${packageName}:id/`.length);
                // @thirdPackage:id/name
                const refIdMatch = id.match(/@\+(.*):id\/(.*)/) || id.match(/@(.*):id\/(.*)/);
                if (refIdMatch) id = refIdMatch[1] + ':' + refIdMatch[2];
                ele.setAttribute('android:id', packageNamePreFix + id);
                if (!refIdMatch) definedIds.add(id);
            }

            // attr value "@xxxx/xxxx" ==> "@packageName:xxxx/xxxx"
            if (packageNamePreFix) {
                Array.from(ele.attributes).forEach((attr) => {
                    const match = attr.value.match(/@([^:]*)\/(.*)/);
                    if (match) {
                        ele.setAttribute(attr.name, `@${packageNamePreFix + match[1]}/${match[2]}`);
                    }
                });
            }

            //remove xmlns & xmlns:android, no need when run
            ele.removeAttribute('xmlns');
            ele.removeAttribute('xmlns:android');

            for (var child of Array.from(ele.children)) {
                deepTravelElement(child);
            }
        }
    }


    function traverseFile(path, callback) {
        if (path.indexOf('.') === 0) return;
        if (fs.statSync(path).isDirectory()) {
            const dirs = fs.readdirSync(path);
            dirs.forEach(function (fileName) {
                const dirPath = path + '/' + fileName;
                traverseFile(dirPath, callback);
            });

        } else {
            callback(path);
        }
    }
}
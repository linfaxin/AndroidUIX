var common_build_module_res = require('./common_build_module_res');

var androidUIPackageName = process.argv[2];
if (!androidUIPackageName && require('fs').existsSync('res')) {
    console.warn(`library miss defined androidUIPackageName in package.json, will case error if library's resource fileName same as app's:\n ${process.cwd()}`);
}
common_build_module_res({
    refs: ['../androidui-sdk-ref.d.ts', '../../../../build-tool/build-tool-pack-in.ts'],
    packageName: androidUIPackageName
});

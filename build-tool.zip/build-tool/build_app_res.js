var common_build_module_res = require('./common_build_module_res');
common_build_module_res({
    refs: ['../androidui-sdk/android-ui.d.ts', '../build/lib.d.ts']
});

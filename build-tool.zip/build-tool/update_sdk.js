/**
 * Created by linfaxin on 16/5/14.
 */

var fs = require('fs');
var child_process = require('child_process');

child_process.exec('npm update androiduix --save-dev', function(err,stdout,stderr){
    if (err) {
        console.error(`exec error: ${err}`);
        console.log('stderr:\n' + stderr);
        console.log('stdout:\n' + stdout);
        return;
    }

    var path = "node_modules/androiduix/dist/";
    var files = fs.readdirSync(path);
    files.forEach(function(fileName){
        fs.writeFileSync('./androidui-sdk/'+fileName, fs.readFileSync(path + '/' + fileName));
    });

    console.log('update sdk version success.');
});